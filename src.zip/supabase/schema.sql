-- Baby Congratulations - Supabase Schema
-- Run this entire file in the Supabase SQL Editor.

-- 1. Enable the uuid extension (needed for gen_random_uuid)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  message text NOT NULL,
  photo_url text,
  approved boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- 3. Grant table-level privileges (required before RLS policies take effect)
GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT SELECT, INSERT ON public.messages TO anon;

-- 4. Enable Row Level Security
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- 4. RLS policies
-- Anyone (anon or authenticated) can INSERT a new message
CREATE POLICY "Anyone can insert messages"
  ON messages FOR INSERT
  TO public
  WITH CHECK (true);

-- Anyone can SELECT only approved messages (public wall)
CREATE POLICY "Anyone can view approved messages"
  ON messages FOR SELECT
  TO public
  USING (approved = true);

-- Authenticated users can SELECT all messages (for admin)
CREATE POLICY "Authenticated users can view all messages"
  ON messages FOR SELECT
  TO authenticated
  USING (true);

-- Only authenticated users can UPDATE (approve/edit)
CREATE POLICY "Authenticated users can update messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (true);

-- Only authenticated users can DELETE
CREATE POLICY "Authenticated users can delete messages"
  ON messages FOR DELETE
  TO authenticated
  USING (true);

-- 5. Storage bucket for baby photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('baby-photos', 'baby-photos', true)
ON CONFLICT (id) DO NOTHING;

-- 6. Storage policies
-- Public read access to baby-photos
CREATE POLICY "Public read access for baby-photos"
  ON storage.objects
  FOR SELECT
  TO public
  USING (bucket_id = 'baby-photos');

-- Authenticated users can upload to baby-photos
CREATE POLICY "Authenticated users can upload baby photos"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'baby-photos');

-- Authenticated users can update their uploads
CREATE POLICY "Authenticated users can update baby photos"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'baby-photos');

-- Authenticated users can delete their uploads
CREATE POLICY "Authenticated users can delete baby photos"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'baby-photos');