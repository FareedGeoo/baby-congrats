export const BABY_NAME = 'Baby';
export const BIRTH_DATE = 'January 1, 2025';
export const WELCOME_MESSAGE = 'Welcome to the world, little one!';