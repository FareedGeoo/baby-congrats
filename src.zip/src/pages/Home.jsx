import { Hero } from '../components/Hero.jsx';
import { GuestbookForm } from '../components/GuestbookForm.jsx';
import { MessageGrid } from '../components/MessageGrid.jsx';
import { Header } from '../components/Header.jsx';
import { useTheme } from '../hooks/useTheme.js';
import { useMessages } from '../hooks/useMessages.js';
import { Loader2 } from 'lucide-react';

export function Home() {
  const { theme, toggleTheme, mounted } = useTheme();
  const { messages, loading, error } = useMessages({ onlyApproved: true });

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center theme-bg">
        <Loader2 className="w-8 h-8 text-[rgb(var(--theme-accent))] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen theme-bg theme-text">
      <Header theme={theme} toggleTheme={toggleTheme} />
      <main id="main" tabIndex={-1}>
        <Hero theme={theme} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <div className="grid gap-8 lg:grid-cols-[minmax(280px,0.72fr)_minmax(0,1.28fr)] lg:gap-12">
            <div>
              <GuestbookForm theme={theme} />
            </div>
            <div>
              <div className="mb-6 flex items-end justify-between">
                <div>
                  <p className="mb-2 text-sm font-bold text-[rgb(var(--theme-accent-text))]">From friends and family</p>
                  <h2 className="font-display text-3xl sm:text-4xl text-[rgb(var(--theme-text))]">
                    Congratulations
                  </h2>
                </div>
              </div>
              {loading ? (
                <div className="h-64 flex items-center justify-center">
                  <Loader2 className="w-6 h-6 text-[rgb(var(--theme-accent))] animate-spin" />
                </div>
              ) : error ? (
                <div className="p-4 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 text-sm">
                  {error}
                </div>
              ) : (
                <MessageGrid messages={messages} theme={theme} />
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}