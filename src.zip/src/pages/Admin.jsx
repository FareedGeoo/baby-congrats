import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase.js';
import { LogOut, User, Trash2, Check, Heart } from 'lucide-react';
import { formatRelativeDate } from '../utils/formatDate.js';

export function Admin() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [authMode, setAuthMode] = useState('signin'); // 'signin' | 'dashboard'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setAuthMode('dashboard');
      } else {
        setAuthMode('signin');
      }
    };
    checkSession();

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuthMode(session ? 'dashboard' : 'signin');
      if (!session) {
        setMessages([]);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (authMode === 'dashboard') {
      loadMessages();
    }
  }, [authMode]);

  const loadMessages = async () => {
    try {
      setLoading(true);
      const { data, error: err } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false });
      if (err) throw err;
      setMessages(data || []);
    } catch (err) {
      setError(err.message || 'Failed to load messages');
    } finally {
      setLoading(false);
    }
  };

  const handleSignIn = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const { error: err } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (err) throw err;
      setAuthMode('dashboard');
    } catch (err) {
      setError(err.message || 'Sign in failed');
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setAuthMode('signin');
    setMessages([]);
  };

  const handleApprove = async (id) => {
    try {
      const { error: err } = await supabase.from('messages').update({ approved: true }).eq('id', id);
      if (err) throw err;
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, approved: true } : m)));
    } catch (err) {
      setError(err.message || 'Failed to approve message');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this message?')) return;
    try {
      const { data: message } = await supabase.from('messages').select('photo_url').eq('id', id).single();
      if (message?.photo_url) {
        const fileName = message.photo_url.split('/').pop();
        await supabase.storage.from('baby-photos').remove([fileName]);
      }
      const { error: err } = await supabase.from('messages').delete().eq('id', id);
      if (err) throw err;
      setMessages((prev) => prev.filter((m) => m.id !== id));
    } catch (err) {
      setError(err.message || 'Failed to delete message');
    }
  };

  if (authMode === 'signin') {
    return (
      <main id="main" tabIndex={-1} className="relative min-h-screen theme-bg theme-text flex items-center justify-center px-4 py-10">
        <div className="absolute left-[-70px] bottom-[-70px] h-52 w-52 rounded-full bg-[rgb(var(--theme-decorative)/0.28)]" aria-hidden="true" />
        <div className="relative max-w-md w-full theme-card p-7 sm:p-10">
          <div className="mb-7 text-center">
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-[rgb(var(--theme-decorative)/0.55)] text-[rgb(var(--theme-accent))]">
              <Heart size={24} fill="currentColor" />
            </div>
            <h2 className="font-display text-3xl text-[rgb(var(--theme-text))]">
              Parent login
            </h2>
          </div>
          <form onSubmit={handleSignIn} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="email" className="label-field">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                spellCheck={false}
                className="input-field"
                required
                aria-invalid={Boolean(error)}
                aria-describedby={error ? 'admin-auth-error' : undefined}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="label-field">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                className="input-field"
                required
                aria-invalid={Boolean(error)}
                aria-describedby={error ? 'admin-auth-error' : undefined}
              />
            </div>
            {error && (
              <div id="admin-auth-error" className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-sm" role="alert" aria-live="polite">
                {error}
              </div>
            )}
            <button type="submit" className="btn-primary w-full py-3">
              Sign In
            </button>
          </form>
        </div>
      </main>
    );
  }
  return (
    <main id="main" tabIndex={-1} className="min-h-screen theme-bg theme-text">
      <header className="bg-[rgb(var(--theme-bg)/0.92)] backdrop-blur-md border-b theme-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-[72px]">
            <div className="flex items-center gap-3">
              <User className="w-6 h-6 text-[rgb(var(--theme-accent))]" />
              <h1 className="font-display text-xl text-[rgb(var(--theme-text))]">Parent keepsake</h1>
            </div>
            <button
              onClick={handleSignOut}
              className="btn-outline px-3 py-2 text-sm flex items-center gap-2"
            >
              <LogOut size={18} /> Sign Out
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <p className="mb-1 text-sm font-bold text-[rgb(var(--theme-accent-text))]">Guestbook</p>
          <h2 className="font-display text-3xl text-[rgb(var(--theme-text))]">
            All messages
          </h2>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <span className="w-6 h-6 text-[rgb(var(--theme-accent))] animate-spin">⟳</span>
          </div>
        ) : error ? (
          <div className="p-4 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 text-sm">
            {error}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-[rgb(var(--theme-border))]">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-[rgb(var(--theme-text-secondary))]">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-[rgb(var(--theme-text-secondary))]">Message</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-[rgb(var(--theme-text-secondary))]">Photo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-[rgb(var(--theme-text-secondary))]">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-[rgb(var(--theme-text-secondary))]">Date</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-[rgb(var(--theme-text-secondary))]">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[rgb(var(--theme-border))]">
                {messages.map((msg) => (
                  <tr key={msg.id}>
                    <td className="px-6 py-4">
                      <span className="text-[rgb(var(--theme-text))]">{msg.name}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[rgb(var(--theme-text-secondary))] text-sm">{msg.message}</span>
                    </td>
                    <td className="px-6 py-4">
                      {msg.photo_url ? (
                        <span className="text-[rgb(var(--theme-text-secondary))] text-sm">📷 Photo</span>
                      ) : (
                        <span className="text-[rgb(var(--theme-text-secondary))] text-sm">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {msg.approved ? (
                        <span className="text-xs font-medium text-green-600 bg-green-50 dark:bg-green-900/20 px-2 py-1 rounded">Approved</span>
                      ) : (
                        <span className="text-xs font-medium text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded">Pending</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs text-[rgb(var(--theme-text-secondary))]">{formatRelativeDate(msg.created_at)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {!msg.approved && (
                        <button
                          onClick={() => handleApprove(msg.id)}
                          className="text-xs font-medium text-green-600 hover:text-green-500 dark:text-green-400"
                        >
                          <Check size={14} className="mr-1" /> Approve
                        </button>
                      )}
                      <button
                        onClick={() => handleDelete(msg.id)}
                        className="ml-3 text-xs font-medium text-red-600 hover:text-red-500 dark:text-red-400"
                      >
                        <Trash2 size={14} className="mr-1" /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  );
}