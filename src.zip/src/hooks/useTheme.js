import { useEffect, useState, useCallback } from 'react';

const THEME_KEY = 'baby-congrats-theme';
const DEFAULT_THEME = 'boy';

export function useTheme() {
  const [theme, setTheme] = useState(DEFAULT_THEME);
  const [mounted, setMounted] = useState(false);

  const applyTheme = useCallback((nextTheme) => {
    const root = document.documentElement;
    root.removeAttribute('data-theme');
    root.setAttribute('data-theme', nextTheme);
    const themeColor = document.querySelector('meta[name="theme-color"]');
    if (themeColor) {
      themeColor.setAttribute('content', nextTheme === 'girl' ? '#FFF7F9' : '#F4F8FD');
    }
    localStorage.setItem(THEME_KEY, nextTheme);
  }, []);

  useEffect(() => {
    setMounted(true);

    // Priority: URL param > localStorage > system preference > default
    const urlParams = new URLSearchParams(window.location.search);
    const urlTheme = urlParams.get('theme');

    let nextTheme;
    if (urlTheme === 'boy' || urlTheme === 'girl') {
      nextTheme = urlTheme;
    } else {
      const stored = localStorage.getItem(THEME_KEY);
      if (stored === 'boy' || stored === 'girl') {
        nextTheme = stored;
      } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        nextTheme = DEFAULT_THEME;
      } else {
        nextTheme = DEFAULT_THEME;
      }
    }

    setTheme(nextTheme);
    applyTheme(nextTheme);
  }, [applyTheme]);

  const toggleTheme = useCallback(() => {
    const nextTheme = theme === 'boy' ? 'girl' : 'boy';
    setTheme(nextTheme);
    applyTheme(nextTheme);
  }, [theme, applyTheme]);

  return { theme, toggleTheme, mounted };
}