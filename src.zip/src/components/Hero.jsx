import { BABY_NAME, BIRTH_DATE, WELCOME_MESSAGE } from '../config.js';
import { Heart, Cloud, Sparkles } from 'lucide-react';

export function Hero({ theme }) {
  const isBoy = theme === 'boy';

  return (
    <section className="relative overflow-hidden border-b theme-border">
      <div className="absolute right-[-80px] top-[-110px] h-[280px] w-[280px] rounded-full border-[44px] border-[rgb(var(--theme-decorative))] opacity-30" aria-hidden="true" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-[minmax(0,1fr)_340px]">
          <div className="animate-fade-in">
            <p className="mb-5 flex items-center gap-2 text-sm font-bold text-[rgb(var(--theme-accent-text))]">
              {isBoy ? <Cloud size={18} /> : <Heart size={18} />}
              Born {BIRTH_DATE}
            </p>
            <h1 className="font-display max-w-3xl text-[clamp(4.25rem,13vw,9rem)] leading-[0.82] tracking-[-0.055em] text-[rgb(var(--theme-text))]">
              {BABY_NAME}
            </h1>
            <p className="mt-7 max-w-xl text-lg leading-8 text-[rgb(var(--theme-text-secondary))] sm:text-xl">
              {WELCOME_MESSAGE}
            </p>
          </div>

          <div className="relative mx-auto w-full max-w-[300px] animate-slide-up" style={{ animationDelay: '0.12s' }}>
            <div className="absolute -left-5 -top-5 z-10 h-12 w-12 rotate-[-8deg] rounded-2xl bg-[rgb(var(--theme-highlight))] shadow-sm flex items-center justify-center text-[rgb(var(--theme-text))]">
              <Sparkles size={21} />
            </div>
            <div className="theme-card relative aspect-[4/5] rotate-[2deg] p-4">
              <div className="h-full rounded-[18px] border border-[rgb(var(--theme-border))] bg-[rgb(var(--theme-decorative)/0.28)] flex flex-col items-center justify-center text-center">
                <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-[rgb(var(--theme-card-bg))] shadow-sm">
                  {isBoy ? (
                    <Cloud size={38} className="text-[rgb(var(--theme-accent))]" strokeWidth={1.5} />
                  ) : (
                    <Heart size={38} className="text-[rgb(var(--theme-accent))]" strokeWidth={1.5} />
                  )}
                </div>
                <p className="font-display text-3xl text-[rgb(var(--theme-text))]">Welcome</p>
                <p className="mt-2 text-sm font-bold text-[rgb(var(--theme-text-secondary))]">to our sweetest new story</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}