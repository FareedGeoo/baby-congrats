import { useState } from 'react';
import { supabase } from '../lib/supabase.js';
import { validateImageFile, compressImage } from '../utils/compressImage.js';
import { Mail, Image, CheckCircle2, Heart } from 'lucide-react';

export function GuestbookForm({ theme }) {
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);
  const [fieldErrors, setFieldErrors] = useState({});

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const validation = validateImageFile(file);
    if (!validation.valid) {
      setError(validation.error);
      setFieldErrors((current) => ({ ...current, photo: validation.error }));
      return;
    }

    setError(null);
    setFieldErrors((current) => ({ ...current, photo: null }));
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!name.trim() || !message.trim()) {
      setError('Please fill in your name and message.');
      setFieldErrors({
        name: name.trim() ? null : 'Enter your name.',
        message: message.trim() ? null : 'Enter a message.',
      });
      return;
    }

    setFieldErrors({});
    setSubmitting(true);

    try {
      let photoUrl = null;

      if (photo) {
        const compressed = await compressImage(photo);
        const fileExt = compressed.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('baby-photos')
          .upload(fileName, compressed, {
            cacheControl: '3600',
            upsert: false,
          });

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage.from('baby-photos').getPublicUrl(fileName);
        photoUrl = urlData.publicUrl;
      }

      const { error: dbError } = await supabase.from('messages').insert({
        name: name.trim(),
        message: message.trim(),
        photo_url: photoUrl,
        approved: false,
      });

      if (dbError) throw dbError;

      setSubmitted(true);
      setName('');
      setMessage('');
      setPhoto(null);
      setPhotoPreview(null);
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="theme-card p-8 text-center animate-fade-in" role="status" aria-live="polite">
        <div className="w-16 h-16 bg-[rgb(var(--theme-decorative)/0.5)] rounded-full flex items-center justify-center mx-auto mb-4 text-[rgb(var(--theme-accent))]">
          <CheckCircle2 size={32} />
        </div>
        <h3 className="font-display text-2xl text-[rgb(var(--theme-text))] mb-2">Thank you!</h3>
        <p className="text-sm leading-6 text-[rgb(var(--theme-text-secondary))]">
          Your message has been received and will appear once approved by the parents.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="theme-card p-6 sm:p-8 space-y-5" noValidate>
      <div className="mb-1">
        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full bg-[rgb(var(--theme-decorative)/0.55)] text-[rgb(var(--theme-accent))]">
          <Heart size={19} fill="currentColor" />
        </div>
        <h2 className="font-display text-3xl text-[rgb(var(--theme-text))]">Leave a wish</h2>
        <p className="mt-2 text-sm leading-6 text-[rgb(var(--theme-text-secondary))]">
          Add a few words to this little one's keepsake.
        </p>
      </div>
      <div className="space-y-2">
        <label htmlFor="name" className="label-field">
          Your Name
        </label>
        <input
          id="name"
          name="name"
          type="text"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            if (fieldErrors.name) setFieldErrors((current) => ({ ...current, name: null }));
          }}
          placeholder="e.g. Jane Doe"
          autoComplete="name"
          className="input-field"
          required
          aria-required="true"
          aria-invalid={Boolean(fieldErrors.name)}
          aria-describedby={fieldErrors.name ? 'name-error' : undefined}
        />
        {fieldErrors.name && (
          <p id="name-error" className="text-sm text-red-700 dark:text-red-300">
            {fieldErrors.name}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <label htmlFor="message" className="label-field">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          value={message}
          onChange={(e) => {
            setMessage(e.target.value);
            if (fieldErrors.message) setFieldErrors((current) => ({ ...current, message: null }));
          }}
          rows={4}
          placeholder="Share your congratulations…"
          className="input-field"
          required
          aria-required="true"
          aria-invalid={Boolean(fieldErrors.message)}
          aria-describedby={fieldErrors.message ? 'message-error' : undefined}
        />
        {fieldErrors.message && (
          <p id="message-error" className="text-sm text-red-700 dark:text-red-300">
            {fieldErrors.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <label htmlFor="photo" className="label-field">
          Optional Photo
        </label>
        <input
          id="photo"
          name="photo"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handlePhotoChange}
          className="block w-full text-sm text-[rgb(var(--theme-text-secondary))] file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[rgb(var(--theme-accent-text))] file:text-white hover:file:bg-[rgb(var(--theme-accent-text-hover))] transition-colors"
          aria-invalid={Boolean(fieldErrors.photo)}
          aria-describedby={fieldErrors.photo ? 'photo-error' : undefined}
        />
        {fieldErrors.photo && (
          <p id="photo-error" className="text-sm text-red-700 dark:text-red-300">
            {fieldErrors.photo}
          </p>
        )}
        {photoPreview && (
          <div className="flex items-center gap-2">
            <Image className="w-4 h-4" />
            <span className="text-sm text-[rgb(var(--theme-text-secondary))]">Photo attached</span>
          </div>
        )}
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-sm" role="alert" aria-live="polite">
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="btn-primary w-full sm:w-auto py-3 flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
      >
        <span className="sr-only" role="status" aria-live="polite">
          {submitting ? 'Submitting' : ''}
        </span>
        {submitting ? (
          <>
            <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            Submitting…
          </>
        ) : (
          <>
            <Mail size={20} />
            Send wish
          </>
        )}
      </button>
    </form>
  );
}