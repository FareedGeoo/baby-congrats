import { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';

export function Lightbox({ isOpen, onClose, src, alt }) {
  const dialogRef = useRef(null);
  const closeButtonRef = useRef(null);
  const previousFocusRef = useRef(null);
  const [imageFailed, setImageFailed] = useState(false);

  useEffect(() => {
    if (!isOpen) return undefined;

    setImageFailed(false);
    previousFocusRef.current = document.activeElement;
    closeButtonRef.current?.focus();

    const previousOverflow = document.body.style.overflow;
    const previousOverscroll = document.documentElement.style.overscrollBehavior;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overscrollBehavior = 'contain';

    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }

      if (event.key !== 'Tab') return;

      const focusableElements = dialogRef.current?.querySelectorAll(
        'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (!focusableElements?.length) {
        event.preventDefault();
        dialogRef.current?.focus();
        return;
      }

      const firstElement = focusableElements[0];
      const lastElement = focusableElements[focusableElements.length - 1];
      if (event.shiftKey && document.activeElement === firstElement) {
        event.preventDefault();
        lastElement.focus();
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = previousOverflow;
      document.documentElement.style.overscrollBehavior = previousOverscroll;
      previousFocusRef.current?.focus();
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      ref={dialogRef}
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 overscroll-contain"
      role="dialog"
      aria-modal="true"
      aria-label="Photo lightbox"
      onClick={onClose}
      tabIndex={-1}
    >
      <div
        className="relative max-w-full max-h-full flex items-center justify-center"
        onClick={(event) => event.stopPropagation()}
      >
        {imageFailed ? (
          <div className="flex h-[360px] w-[480px] max-h-[85vh] max-w-full flex-col items-center justify-center gap-3 rounded-lg border border-white/10 bg-white/10 text-white">
            <X size={28} aria-hidden="true" />
            <span className="font-bold">Photo unavailable</span>
          </div>
        ) : (
          <img
            src={src}
            alt={alt || 'Photo shared with the congratulations message'}
            width="1200"
            height="900"
            className="max-w-full max-h-[85vh] w-auto h-auto rounded-lg shadow-2xl border border-white/10"
            onError={() => setImageFailed(true)}
          />
        )}
      </div>

      <button
        ref={closeButtonRef}
        onClick={(event) => {
          event.stopPropagation();
          onClose();
        }}
        className="absolute top-4 right-4 z-10 bg-white/10 hover:bg-white/20 text-white p-2 rounded-lg transition-colors"
        aria-label="Close lightbox"
      >
        <X size={24} />
      </button>

    </div>
  );
}