import { useState, useEffect } from 'react';
import { MessageCard } from './MessageCard.jsx';
import { Lightbox } from './Lightbox.jsx';

export function MessageGrid({ messages, theme }) {
  const [lightbox, setLightbox] = useState({ isOpen: false, src: '', alt: '' });

  useEffect(() => {
    const handler = (e) => {
      setLightbox({ isOpen: true, src: e.detail.src, alt: e.detail.alt });
    };
    window.addEventListener('open-lightbox', handler);
    return () => window.removeEventListener('open-lightbox', handler);
  }, []);

  const sorted = [...messages].sort(
    (a, b) => new Date(b.created_at) - new Date(a.created_at)
  );

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
      {sorted.length === 0 ? (
        <div className="col-span-full theme-card text-center py-12 px-6">
          <p className="text-[rgb(var(--theme-text-secondary))]">No messages yet. Be the first to leave one!</p>
        </div>
      ) : (
        sorted.map((message) => (
          <MessageCard key={message.id} message={message} theme={theme} />
        ))
      )}

      <Lightbox
        isOpen={lightbox.isOpen}
        onClose={() => setLightbox({ isOpen: false, src: '', alt: '' })}
        src={lightbox.src}
        alt={lightbox.alt}
      />
    </div>
  );
}