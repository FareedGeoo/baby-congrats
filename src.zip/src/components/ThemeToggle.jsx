import { Heart, Cloud } from 'lucide-react';

export function ThemeToggle({ theme, toggleTheme }) {
  const isBoy = theme === 'boy';

  return (
    <button
      onClick={toggleTheme}
      aria-label={`Switch to ${isBoy ? 'Baby Girl' : 'Baby Boy'} theme`}
      className="btn-outline h-11 min-w-11 px-2 sm:px-3 gap-2"
    >
      {isBoy ? (
        <>
          <Heart className="w-4 h-4" aria-hidden="true" />
          <span className="hidden sm:inline">Girl theme</span>
        </>
      ) : (
        <>
          <Cloud className="w-4 h-4" aria-hidden="true" />
          <span className="hidden sm:inline">Boy theme</span>
        </>
      )}
    </button>
  );
}