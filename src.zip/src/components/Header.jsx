import { Link } from 'react-router-dom';
import { ThemeToggle } from './ThemeToggle.jsx';
import { useTheme } from '../hooks/useTheme.js';

export function Header({ theme, toggleTheme }) {
  return (
    <header className="sticky top-0 z-40 bg-[rgb(var(--theme-bg)/0.92)] backdrop-blur-md border-b theme-border">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[72px]">
          <div className="flex min-w-0 items-center gap-2 sm:gap-3">
            <div className="h-10 w-10 shrink-0 rounded-[14px] bg-[rgb(var(--theme-accent))] flex items-center justify-center text-white shadow-sm rotate-[-3deg]">
              <span className="font-display text-lg">b</span>
            </div>
            <Link
              to="/"
              className="flex min-w-0 h-11 items-center truncate font-display text-base sm:text-xl font-bold text-[rgb(var(--theme-text))] hover:text-[rgb(var(--theme-accent-text))] transition-colors"
            >
              A little love for baby
            </Link>
          </div>

          <div className="flex shrink-0 items-center gap-1 sm:gap-2">
            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
            <Link
              to="/admin"
              className="btn-outline h-11 min-w-11 px-3 text-sm text-[rgb(var(--theme-text))] hover:bg-[rgb(var(--theme-border))]"
            >
              Admin
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}