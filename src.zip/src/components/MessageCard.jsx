import { useState } from 'react';
import { ImageOff } from 'lucide-react';
import { formatRelativeDate } from '../utils/formatDate.js';

export function MessageCard({ message, theme }) {
  const [imageFailed, setImageFailed] = useState(false);

  return (
    <article className="theme-card animate-fade-in p-5 sm:p-6">
      {message.photo_url && (
        <div className="relative mb-5 aspect-[4/3] rounded-[18px] overflow-hidden border theme-border">
          <button
            onClick={(e) => {
              e.stopPropagation();
              window.dispatchEvent(new CustomEvent('open-lightbox', { detail: { src: message.photo_url, alt: `Photo shared by ${message.name}` } }));
            }}
            className="w-full h-full cursor-pointer group"
            aria-label={`View photo from ${message.name}`}
            disabled={imageFailed}
          >
            {imageFailed ? (
              <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[rgb(var(--theme-decorative)/0.35)] text-[rgb(var(--theme-text-secondary))]">
                <ImageOff size={28} aria-hidden="true" />
                <span className="text-sm font-bold">Photo unavailable</span>
              </div>
            ) : (
              <>
                <img
                  src={message.photo_url}
                  alt={`Photo shared by ${message.name}`}
                  width="800"
                  height="600"
                  loading="lazy"
                  onError={() => setImageFailed(true)}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg aria-hidden="true" className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                </div>
              </>
            )}
          </button>
        </div>
      )}

      <p className="font-display text-[1.28rem] leading-[1.55] text-[rgb(var(--theme-text))]">
        {message.message}
      </p>
      <footer className="mt-5 flex items-end justify-between gap-4 border-t theme-border pt-4">
        <p className="text-sm font-bold text-[rgb(var(--theme-text))]">
          <span className="mr-2 text-[rgb(var(--theme-accent-text))]" aria-hidden="true">—</span>
          {message.name}
        </p>
        <time className="shrink-0 text-xs text-[rgb(var(--theme-text-secondary))]" dateTime={message.created_at}>
          {formatRelativeDate(message.created_at)}
        </time>
      </footer>
    </article>
  );
}